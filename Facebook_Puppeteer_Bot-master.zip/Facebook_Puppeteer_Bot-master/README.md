# Facebook_Puppeteer_Bot

In this Project I coded a facebook puppeteer robot to automatically send a post every 10 seconds you can watch a tutorial showing the detailed explanation of this on my youtube channel

:) Thanks
